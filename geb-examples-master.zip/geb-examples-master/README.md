geb-examples
============

Various Geb scripts as discussed on http://qualityshepherd.com

Project overview video: https://www.youtube.com/watch?v=7ufBPYXYXDg