package data

class UserData {
    // MoodleSandbox user maps...
    static admin = [username: 'admin', password: 'sandbox', fullname: 'Admin User']
    static manager = [username: 'manager', password: 'sandbox']
    static teacher = [username: 'teacher', password: 'sandbox', fullname: 'Terri Teacher']
    static student = [username: 'student', password: 'sandbox']

}
